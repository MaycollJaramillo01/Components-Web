<?php
/*
Plugin Name: WP Testimonials Captcha
Description: Sistema de testimonios con JSON + Captcha.
Version: 1.0
Author: Maycoll
*/

if ( ! defined('ABSPATH') ) exit;

// === Shortcode para mostrar el formulario + reseñas ===
function wp_testimonials_shortcode() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'views/testimonials-form.php';
    return ob_get_clean();
}
add_shortcode('testimonials_form', 'wp_testimonials_shortcode');

// === Endpoint CAPTCHA ===
add_action('init', function(){
    add_rewrite_rule('captcha.svg$', 'index.php?wp_captcha=1', 'top');
});
add_filter('query_vars', function($vars){
    $vars[] = 'wp_captcha';
    return $vars;
});
add_action('template_redirect', function(){
    if (get_query_var('wp_captcha') == 1) {
        include plugin_dir_path(__FILE__) . 'captcha.php';
        exit;
    }
});

// === Manejo envío de reseñas ===
add_action('admin_post_nopriv_wp_insert_testimonial', 'wp_insert_testimonial');
add_action('admin_post_wp_insert_testimonial', 'wp_insert_testimonial');

function wp_insert_testimonial() {
    session_start();
    $errors = [];

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $text    = sanitize_textarea_field($_POST['reviews'] ?? '');
    $captcha = sanitize_text_field($_POST['captcha'] ?? '');
    $stars   = intval($_POST['estrellas'] ?? 0);
    $date    = sanitize_text_field($_POST['fecha'] ?? date('Y-m-d'));

    if ($stars < 1 || $stars > 5) $errors['stars'] = 'Please select a rating.';
    if (!$name) $errors['name'] = 'Name is required.';
    if (!$text) $errors['reviews'] = 'Comments are required.';
    if (!isset($_SESSION['captcha']) || strcasecmp($captcha, $_SESSION['captcha']) !== 0) {
        $errors['captcha'] = 'Invalid CAPTCHA.';
    }

    if ($errors) {
        $_SESSION['errors'] = $errors;
        wp_safe_redirect(wp_get_referer());
        exit;
    }

    unset($_SESSION['captcha']);

    $dir  = plugin_dir_path(__FILE__) . 'data/';
    $file = $dir . 'testimonials.json';

    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $reviews = [];
    if (file_exists($file)) {
        $raw = file_get_contents($file);
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) $reviews = $decoded;
    }

    $new = [
        'name'   => $name,
        'rating' => $stars,
        'text'   => $text,
        'date'   => $date,
    ];

    array_unshift($reviews, $new);

    file_put_contents($file, json_encode($reviews, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

    $_SESSION['flash_success'] = 'Thanks! Your review has been submitted.';
    wp_safe_redirect(wp_get_referer());
    exit;
}
