<form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
  <input type="hidden" name="action" value="wp_insert_testimonial">
  <input type="hidden" name="fecha" value="<?php echo esc_attr(date('Y-m-d')); ?>">

  <!-- Campos: name, reviews, estrellas -->
  <input type="text" name="name" placeholder="Your name">
  <textarea name="reviews" placeholder="Your review"></textarea>
  <input type="number" name="estrellas" min="1" max="5">

  <img src="<?php echo home_url('captcha.svg'); ?>" alt="captcha">
  <input type="text" name="captcha" placeholder="Enter code">

  <button type="submit">Submit</button>
</form>
